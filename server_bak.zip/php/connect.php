<?php

	$conn=mysql_connect('localhost', 'root', 'apmsetup');	// db 연결 부분
	$db=mysql_select_db("smart_morningcall", $conn);	 // db 선택 부분

?>