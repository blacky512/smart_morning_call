<?php
	session_start();
	include "./connect.php";

//	$temp = json_decode(file_get_contents('php://input') , true);
//	print_r($temp);
	$temp = $_POST;



	// 안쓰는 아이 


?>