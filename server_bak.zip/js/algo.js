$(document).ready(function(){

	/* html이나 안드로이드에서 algo.js를 이용하여
	   algo_update.php에서 algo_array.php 로 이동.
	   값도 넘겨준다.  

	*/

});