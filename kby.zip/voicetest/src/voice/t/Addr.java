package voice.t;

/** 
 * 서버 주소, 포트번호
 * @author kyobum
 * 
 * 
 *  
 */
public class Addr {
	static String 	host	= "";
	static int 		port 	= 7771; 
}
